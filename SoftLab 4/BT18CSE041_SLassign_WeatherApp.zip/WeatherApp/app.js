var input = document.querySelector('.input_text');
var main = document.querySelector('#name');
var temp = document.querySelector('.temp');
var desc = document.querySelector('.desc');
var clouds = document.querySelector('.clouds');
var button= document.querySelector('.submit');


button.addEventListener('click', function(name){
fetch('https://api.openweathermap.org/data/2.5/weather?q='+input.value+'&appid=355ca862e2d6ddc53117d9e8eba34d36')
.then(response => response.json())
.then(data => {
  var tempValue = data['main']['temp'];
  var nameValue = data['name'];
  var descValue = data['weather'][0]['description'];
  tempValue = tempValue - 273
  tempValue = tempValue.toFixed(2)
  main.innerHTML = nameValue;
  desc.innerHTML = "Desc - "+descValue;
  str = "o"
  temp.innerHTML = "Temp - "+tempValue+str.sup()+"C";
  input.value ="";

})

.catch(err => alert("Wrong city name!"));
})
